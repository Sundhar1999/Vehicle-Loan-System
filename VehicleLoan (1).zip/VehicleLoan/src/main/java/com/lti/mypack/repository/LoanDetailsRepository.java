package com.lti.mypack.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.lti.mypack.model.LoanDetails;
import com.lti.mypack.model.UserDetails;


public interface LoanDetailsRepository extends JpaRepository<LoanDetails, Integer>{
	@Query("select l from LoanDetails l where l.user.uid=?1")
	public LoanDetails findByUser(int uid);
	

}
