package com.lti.mypack.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.lti.mypack.model.LoanDetails;
//import com.lti.mypack.model.LoanDetails;
import com.lti.mypack.model.UserDetails;
import com.lti.mypack.service.LoanService;

@RestController
@CrossOrigin(origins="http://localhost:4200")
@RequestMapping("/vehicleLoan/api")
public class LoanController {
	@Autowired
	private LoanService loanService;
	
	@PostMapping("/signup")
	public boolean addProduct(@RequestBody UserDetails userDetails){
		return loanService.addUserDetails(userDetails);
	}
	
	@GetMapping("/users")
	public List<UserDetails> getAllUsers(){
		return loanService.getUserDetails();
	}
	
	@GetMapping("/usersbyemail/{email}")
	public UserDetails getUserByEmail(@PathVariable(value="email") String email) {
		return loanService.findUserDetailsByEmail(email);
	}
	
	@GetMapping("/loandetails")
	public List<LoanDetails> getAllLoanDetails(){
		return loanService.getLoanDetails();
	}
	
	
	@GetMapping("/loandetails/{uid}")
	public LoanDetails getLoanDetailsByUid(@PathVariable(value="uid") int uid) {
	   return loanService.findLoanDetails(uid);
	   
	}
	
	

}
