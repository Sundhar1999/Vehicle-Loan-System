package com.lti.mypack.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lti.mypack.model.LoanDetails;
import com.lti.mypack.model.UserDetails;
import com.lti.mypack.repository.LoanDetailsRepository;
import com.lti.mypack.repository.UserDetailsRepository;

@Service
@Transactional
public class LoanServiceImpl implements LoanService {
	
	@Autowired
	private UserDetailsRepository userRepo;
	
	@Autowired
	private LoanDetailsRepository loanRepo;

	@Override
	public List<UserDetails> getUserDetails() {
		return userRepo.findAll();
	}

	@Override
	public boolean addUserDetails(UserDetails userdetails) {
		userRepo.save(userdetails);
		return true;
	}

	@Override
	public boolean updateUserDetails(UserDetails userdetails) {
		
		return false;
	}

	@Override
	public boolean deleteUserDetails(UserDetails userdetails) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public UserDetails findUserDetails(int userid) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public UserDetails findUserDetailsByEmail(String Email) {
		
			
			return userRepo.findByEmail(Email);
		
	}

	

	@Override
	public List<LoanDetails> getLoanDetails() {
		
		return loanRepo.findAll();
	}

//	@Override
//	public void addLoanDetails(LoanDetails loanDetails, int uid) {
//		UserDetails userDetails=userRepo.getById(uid);
//		loanDetails.setUser(userDetails);
//		loanRepo.save(loanDetails);
//	}

//	@Override
//	public LoanDetails findLoanDetails(int uid) {
//		UserDetails user=userRepo.getById(uid);
//		return loanRepo.findByUser(user);
//		
//	}
	
	@Override
	public LoanDetails findLoanDetails(int uid) {
//		UserDetails user=userRepo.getById(uid);
		return loanRepo.findByUser(uid);
		     
		
	}

	

	



	
	}
