package com.lti.mypack.model;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="loandetails")
public class LoanDetails {
	
	@Id
	@GeneratedValue(generator = "sequence", strategy=GenerationType.SEQUENCE)
	@Column(name="L_ID")
	private int lid;
	
	
	
	
	@OneToOne(cascade=CascadeType.ALL)
	@JoinColumn(name = "U_ID")
	private UserDetails user;
	
	@Column(name="LOAN_AMOUNT")
	private int loanamount;
	
	

	public UserDetails getUser() {
		return user;
	}

	public void setUser(UserDetails user) {
		this.user = user;
	}

	@Column(name="LOAN_TENURE_YEARS")
	private int loantenureyears;
	
	@Column(name="RATEOFINTEREST_BIKE")
	private String rateofinterestbike;
	
	@Column(name="RATEOFINTEREST_CAR")
	private String rateofinterestcar;
	
	@Column(name="BEST_RATE")
	private int bestrate;
	
	@Column(name="PROCESSING_FEE")
	private int processingfee;

	public int getLid() {
		return lid;
	}

	public void setLid(int lid) {
		this.lid = lid;
	}



	public int getLoanamount() {
		return loanamount;
	}

	public void setLoanamount(int loanamount) {
		this.loanamount = loanamount;
	}

	public int getLoantenureyears() {
		return loantenureyears;
	}

	public void setLoantenureyears(int loantenureyears) {
		this.loantenureyears = loantenureyears;
	}

	public String getRateofinterestbike() {
		return rateofinterestbike;
	}

	public void setRateofinterestbike(String rateofinterestbike) {
		this.rateofinterestbike = rateofinterestbike;
	}

	public String getRateofinterestcar() {
		return rateofinterestcar;
	}

	public void setRateofinterestcar(String rateofinterestcar) {
		this.rateofinterestcar = rateofinterestcar;
	}

	public int getBestrate() {
		return bestrate;
	}

	public void setBestrate(int bestrate) {
		this.bestrate = bestrate;
	}

	public int getProcessingfee() {
		return processingfee;
	}

	public void setProcessingfee(int processingfee) {
		this.processingfee = processingfee;
	}
	
	

}

