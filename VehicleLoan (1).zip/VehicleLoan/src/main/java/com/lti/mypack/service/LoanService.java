package com.lti.mypack.service;

import java.util.List;

import com.lti.mypack.model.LoanDetails;
import com.lti.mypack.model.UserDetails;

public interface LoanService {

	public List<UserDetails> getUserDetails();

	public boolean addUserDetails(UserDetails userdetails);

	public boolean updateUserDetails(UserDetails userdetails);

	public boolean deleteUserDetails(UserDetails userdetails);

	public UserDetails findUserDetails(int userid);

	public UserDetails findUserDetailsByEmail(String Email);
	
	public List<LoanDetails> getLoanDetails();
	
//	public void addLoanDetails(LoanDetails loanDetails,int uid);
	
	public LoanDetails findLoanDetails(int uid);
	
	

}
